/** Automatically generated file. DO NOT MODIFY */
package com.mobile.android.smsspamfilter;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}