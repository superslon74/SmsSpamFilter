package com.mobile.android.smsspamfilter.wrapper;

import android.content.Context;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds.Phone;
/*
Created by superslon74@gmail.com 

skype: superslon74

phone: +380935767412
 */ 

public class ContactsWrapper {

	public static boolean isFromContacts(Context context, String phone) {
		boolean isFromContacts = false;
		String[] projection = new String[] { Phone.NUMBER };
		String selection = "REPLACE( " + Phone.NUMBER + ", ' ', '')" + "= '" + phone + "'";
		Cursor cursor = context.getContentResolver().query(ContactsContract.CommonDataKinds.Phone.CONTENT_URI, projection, selection, null,
				null);
		while (cursor.moveToNext()) {
			isFromContacts = true;
		}
		cursor.close();
		return isFromContacts;
	}
}
