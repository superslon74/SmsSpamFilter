package com.mobile.android.smsspamfilter.application;

import android.app.Application;
/*
Created by superslon74@gmail.com 

skype: superslon74

phone: +380935767412
 */ 

public class SmsSpamFilterApplication extends Application {
	
}