package com.mobile.android.smsspamfilter.fragments;
/*
Created by superslon74@gmail.com 

skype: superslon74

phone: +380935767412
 */ 

public interface SettingsRestoreCallback {
	public void onRestore();
}
