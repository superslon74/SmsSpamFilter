package com.mobile.android.smsspamfilter.activities;
/*
Created by superslon74@gmail.com 

skype: superslon74

phone: +380935767412
 */ 

import com.mobile.android.smsspamfilter.log.EmailLogManager;

public interface LoggedActivity {
	public EmailLogManager getLog();
}
